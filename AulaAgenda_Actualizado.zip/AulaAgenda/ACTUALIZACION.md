# AulaAgenda — actualización

Abre CalendarioAcademico.sln en Visual Studio y restaura NuGet. Se conserva SQL Server y el esquema original: la recuperación utiliza un token protegido con caducidad de 30 minutos, vinculado al hash anterior; no requiere tablas nuevas. Si ya tienes la base y las migraciones de la versión anterior, conserva esas migraciones y aplica Update-Database si corresponde. Si es una base nueva, ejecuta Add-Migration InicialSqlServer y Update-Database.

## Correo real
En la terminal de la carpeta del proyecto configura secretos (sustituye los ejemplos):

```powershell
dotnet user-secrets set "Smtp:Host" "smtp.gmail.com"
dotnet user-secrets set "Smtp:Port" "587"
dotnet user-secrets set "Smtp:User" "tu-correo@gmail.com"
dotnet user-secrets set "Smtp:From" "tu-correo@gmail.com"
dotnet user-secrets set "Smtp:Password" "TU-CONTRASENA-DE-APLICACION"
dotnet user-secrets set "PublicBaseUrl" "https://localhost:PUERTO"
```
Usa el puerto HTTPS real de Visual Studio. Gmail exige una contraseña de aplicación cuando está disponible; también puedes usar otro SMTP compatible con STARTTLS. No subas secretos a GitHub. En hosting configura variables Smtp__Host, Smtp__Port, Smtp__User, Smtp__From, Smtp__Password, PublicBaseUrl y ConnectionStrings__AcademicConnection. Mantén las claves de Data Protection persistentes y protegidas en el servidor. Sin SMTP configurado no se envían mensajes. No se publica ningún sitio automáticamente.

## Pruebas pendientes en Visual Studio
- Compilar y ejecutar; solicitar enlace a una cuenta existente, comprobar correo y restablecer contraseña.
- Comprobar que el enlace usado o caducado no permita cambiar la contraseña.
- Probar cambio de contraseña desde ajustes, tema, filtros, exportación y separación de cuentas.
- Verificar correo inexistente y protección antifalsificación.

Se conservan las funciones del ZIP original. Los archivos nuevos tienen comentarios explicativos; no se ha completado documentación literal línea por línea de todos los archivos heredados. No se pudo compilar ni probar SQL Server o SMTP en este entorno. Las sesiones abiertas en otros navegadores no se revocan inmediatamente al cambiar la contraseña.
