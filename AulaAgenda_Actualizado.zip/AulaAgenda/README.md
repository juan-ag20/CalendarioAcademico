# AulaAgenda — ASP.NET Core MVC + Entity Framework Core + Microsoft SQL Server

Esta versión usa el proveedor Microsoft.EntityFrameworkCore.SqlServer, como el solicitado en Visual Studio. Conserva calendario, cuentas de estudiantes, materias, tareas, exámenes, apuntes y recordatorios visuales.

## Paquetes NuGet incluidos
Los cuatro paquetes están en la versión 8.0.13, para el proyecto .NET 8:
- Microsoft.EntityFrameworkCore
- Microsoft.EntityFrameworkCore.SqlServer
- Microsoft.EntityFrameworkCore.Tools
- Microsoft.EntityFrameworkCore.Design

Visual Studio los restaura desde el archivo CalendarioAcademico.csproj. No hace falta instalarlos uno por uno. No actualices uno a una versión mayor distinta de los demás.

## 1. Preparar Visual Studio y SQL Server
Necesitas Visual Studio con ASP.NET y desarrollo web, el SDK de .NET 8 y SQL Server Express LocalDB. Si no tienes LocalDB, abre Visual Studio Installer > Modificar > Componentes individuales y busca SQL Server Express LocalDB.

LocalDB es el motor local de SQL Server que se usará de forma predeterminada. SQL Server Management Studio es una herramienta de administración; por sí sola no sustituye al motor.

## 2. Abrir el proyecto y revisar la conexión
Extrae TODO el ZIP y abre CalendarioAcademico.sln. Elige CalendarioAcademico como proyecto de inicio.

appsettings.json ya contiene esta conexión local con autenticación de Windows:

```json
{
 "ConnectionStrings": {
  "AcademicConnection": "Server=(localdb)\\MSSQLLocalDB;Database=CalendarioAcademico;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True;"
 }
}
```

En JSON, las dos barras invertidas representan una sola barra en la conexión. No requiere contraseña para LocalDB. TrustServerCertificate=True se utiliza aquí para desarrollo local.

Si usas SQL Server Express en otra instancia, reemplaza únicamente la conexión por la que corresponda a tu instalación; por ejemplo:

```json
"AcademicConnection": "Server=.\\SQLEXPRESS;Database=CalendarioAcademico;Trusted_Connection=True;TrustServerCertificate=True;"
```

No supongas que SQLEXPRESS existe: verifica el nombre de tu servidor. Para un servidor con usuario y contraseña, guarda esos datos en Administrar secretos de usuario, en el proyecto; no compartas contraseñas reales dentro del ZIP.

Esta versión tiene un UserSecretsId distinto de la versión anterior para evitar reutilizar una conexión de otro proveedor por accidente. Si configuraste la variable de entorno ConnectionStrings__AcademicConnection, actualízala o elimínala si sobrescribe la conexión de appsettings.json.

## 3. Crear la base de datos y las tablas
1. Restaura los paquetes NuGet y compila la solución.
2. Abre Herramientas > Administrador de paquetes NuGet > Consola del Administrador de paquetes.
3. Selecciona CalendarioAcademico como proyecto predeterminado.
4. Ejecuta en orden:

```powershell
Add-Migration InicialSqlServer
Update-Database
```

Add-Migration genera la carpeta Migrations con el esquema de AcademicContext. Update-Database crea la base y las tablas en la instancia SQL Server configurada, si tu cuenta tiene permisos.

No se incluye una migración generada sin verificar: este entorno no tiene el SDK de .NET para producirla. Una vez que generes esa carpeta, consérvala con tu proyecto; en otro equipo que ya tenga las migraciones basta con Update-Database.

Extrae esta versión en una carpeta nueva. No copies migraciones generadas para un proveedor distinto dentro de este proyecto. La base anterior no se elimina ni se importa automáticamente.

Alternativa por terminal, desde la carpeta del .csproj:

```bash
dotnet tool install --global dotnet-ef --version 8.0.13
dotnet ef migrations add InicialSqlServer
dotnet ef database update
```

Si ya tienes dotnet-ef, utiliza una versión compatible de la generación 8.

## 4. Ejecutar y consultar los datos
Pulsa F5. Crea una cuenta, registra una materia y agrega una actividad.

En Visual Studio, abre Ver > Explorador de objetos de SQL Server. Conecta a `(localdb)\MSSQLLocalDB` y busca la base CalendarioAcademico. Verás Students, Subjects, Activities y __EFMigrationsHistory después de aplicar la migración.

## Cómo funciona
- Program.cs registra AcademicContext mediante AddDbContext y UseSqlServer.
- Data/AcademicContext.cs hereda de DbContext y expone DbSet<Student>, DbSet<Subject> y DbSet<Activity>.
- Students guarda cuentas con correo único y hashes de contraseña.
- Subjects pertenece a un estudiante mediante OwnerId.
- Activities pertenece a una materia mediante SubjectId y OwnerId. La clave foránea compuesta garantiza que ambos identificadores correspondan a la misma materia.
- SQL Server genera los identificadores numéricos de materias y actividades.
- Eliminar una materia elimina sus actividades en cascada.
- Los controladores consultan mediante EF Core y guardan con SaveChangesAsync. Filtran los datos por la cuenta autenticada.

## Verificación y alcance
Se revisaron el cambio de proveedor, la configuración JSON, las relaciones del modelo y el ZIP. No se pudo restaurar NuGet, compilar, generar/aplicar migraciones ni ejecutar contra SQL Server porque este entorno no dispone del SDK ni del motor SQL Server. Comprueba en tu equipo registro, login, edición/eliminación, persistencia y separación entre dos cuentas.

Los recordatorios son avisos dentro de la página. La recuperación por correo se configura según ACTUALIZACION.md; no se han añadido notificaciones push. Esta es una versión académica para desarrollo local.

Referencia oficial: https://learn.microsoft.com/en-us/ef/core/providers/sql-server/
