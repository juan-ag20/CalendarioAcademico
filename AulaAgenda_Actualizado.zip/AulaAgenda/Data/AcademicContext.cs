// Datos. Mapea estudiantes, materias y actividades a SQL Server y define sus relaciones y reglas de eliminación.
using CalendarioAcademico.Models;
using Microsoft.EntityFrameworkCore;
namespace CalendarioAcademico.Data;
public class AcademicContext(DbContextOptions<AcademicContext> options) : DbContext(options) {
 public DbSet<Student> Students => Set<Student>();
 public DbSet<Subject> Subjects => Set<Subject>();
 public DbSet<Activity> Activities => Set<Activity>();
 protected override void OnModelCreating(ModelBuilder model) {
  model.Entity<Student>(e=> {
   e.Property(x=>x.Id).HasMaxLength(36);
   e.Property(x=>x.Name).HasMaxLength(100).IsRequired();
   e.Property(x=>x.Email).HasMaxLength(254).IsRequired();
   e.HasIndex(x=>x.Email).IsUnique();
   e.Property(x=>x.PasswordHash).HasMaxLength(512).IsRequired();
  });
  model.Entity<Subject>(e=> {
   e.Property(x=>x.OwnerId).HasMaxLength(36).IsRequired();
   e.HasAlternateKey(x=>new{x.Id,x.OwnerId});
   e.HasOne<Student>().WithMany().HasForeignKey(x=>x.OwnerId).OnDelete(DeleteBehavior.Cascade);
  });
  model.Entity<Activity>(e=> {
   e.Property(x=>x.OwnerId).HasMaxLength(36).IsRequired();
   e.Property(x=>x.Kind).HasMaxLength(10);
   e.Property(x=>x.Priority).HasMaxLength(10);
   e.Property(x=>x.Status).HasMaxLength(20);
   e.HasOne<Subject>().WithMany().HasForeignKey(x=>new{x.SubjectId,x.OwnerId})
    .HasPrincipalKey(x=>new{x.Id,x.OwnerId}).OnDelete(DeleteBehavior.Cascade);
   e.HasIndex(x=>new{x.OwnerId,x.Date});
  });
 }
}
