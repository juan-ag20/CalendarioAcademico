using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;
using CalendarioAcademico.Data;
using CalendarioAcademico.Models;
using CalendarioAcademico.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace CalendarioAcademico.Controllers;

// Recuperación y cambio de contraseña sin guardar contraseñas en texto plano.
public class PasswordController(AcademicContext db, IDataProtectionProvider protection,
    RecoveryEmail email, IConfiguration config, ILogger<PasswordController> logger) : Controller
{
    private readonly PasswordHasher<Student> hasher = new();
    private ITimeLimitedDataProtector Protector => protection.CreateProtector("AulaAgenda.PasswordReset.v1").ToTimeLimitedDataProtector();
    private record ResetData(string Id, string Hash);

    [HttpGet, AllowAnonymous]
    public IActionResult Forgot() => View(new ForgotPasswordForm());

    [HttpPost, AllowAnonymous, EnableRateLimiting("recovery")]
    public async Task<IActionResult> Forgot(ForgotPasswordForm form)
    {
        // Valida el correo y busca la cuenta sin revelar si existe.
        if (!ModelState.IsValid) return View(form);
        var address = form.Email.Trim().ToLowerInvariant();
        var student = await db.Students.AsNoTracking().SingleOrDefaultAsync(s => s.Email == address);
        if (student is not null)
        {
            try
            {
                // El token expira y queda ligado al hash actual de la contraseña.
                var token = Protector.Protect(JsonSerializer.Serialize(new ResetData(student.Id, student.PasswordHash)), TimeSpan.FromMinutes(30));
                var origin = config["PublicBaseUrl"];
                if (!Uri.TryCreate(origin, UriKind.Absolute, out var uri) || uri.Scheme != "https")
                    throw new InvalidOperationException("Configura PublicBaseUrl HTTPS.");
                var path = Url.Action(nameof(Reset), "Password", new { token });
                await email.SendAsync(student.Email, origin!.TrimEnd('/') + path);
            }
            catch (Exception ex)
            {
                // No se escriben tokens ni credenciales en los registros.
                logger.LogWarning("No se pudo enviar recuperación: {ErrorType}", ex.GetType().Name);
            }
        }
        TempData["Notice"] = "Si existe la cuenta y el correo está configurado, recibirás un enlace de recuperación.";
        return RedirectToAction("Login", "Account");
    }

    [HttpGet, AllowAnonymous]
    public IActionResult Reset(string token) => View(new ResetPasswordForm { Token = token ?? "" });

    [HttpPost, AllowAnonymous, EnableRateLimiting("recovery")]
    public async Task<IActionResult> Reset(ResetPasswordForm form)
    {
        if (!ModelState.IsValid) return View(form);
        ResetData? data;
        try
        {
            data = JsonSerializer.Deserialize<ResetData>(Protector.Unprotect(form.Token));
        }
        catch (Exception ex) when (ex is CryptographicException or JsonException or FormatException)
        {
            data = null;
        }
        if (data is not null)
        {
            var student = await db.Students.AsNoTracking().SingleOrDefaultAsync(s => s.Id == data.Id);
            if (student is not null)
            {
                var hash = hasher.HashPassword(student, form.Password);
                // La actualización condicional impide reutilizar un enlace incluso en solicitudes simultáneas.
                var count = await db.Students.Where(s => s.Id == data.Id && s.PasswordHash == data.Hash)
                    .ExecuteUpdateAsync(set => set.SetProperty(s => s.PasswordHash, hash));
                if (count == 1)
                {
                    await HttpContext.SignOutAsync();
                    TempData["Notice"] = "Contraseña actualizada. Inicia sesión nuevamente.";
                    return RedirectToAction("Login", "Account");
                }
            }
        }
        ModelState.AddModelError("", "El enlace no es válido, expiró o ya fue utilizado.");
        return View(form);
    }

    [Authorize, HttpGet]
    public IActionResult Change() => View(new ChangePasswordForm());

    [Authorize, HttpPost, EnableRateLimiting("recovery")]
    public async Task<IActionResult> Change(ChangePasswordForm form)
    {
        if (!ModelState.IsValid) return View(form);
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var student = await db.Students.AsNoTracking().SingleOrDefaultAsync(s => s.Id == id);
        if (student is null || hasher.VerifyHashedPassword(student, student.PasswordHash, form.CurrentPassword) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "La contraseña actual no es correcta.");
            return View(form);
        }
        var hash = hasher.HashPassword(student, form.Password);
        var count = await db.Students.Where(s => s.Id == id && s.PasswordHash == student.PasswordHash)
            .ExecuteUpdateAsync(set => set.SetProperty(s => s.PasswordHash, hash));
        if (count != 1) return Conflict("La contraseña cambió. Vuelve a iniciar sesión.");
        await HttpContext.SignOutAsync();
        TempData["Notice"] = "Contraseña modificada. Inicia sesión nuevamente.";
        return RedirectToAction("Login", "Account");
    }
}
