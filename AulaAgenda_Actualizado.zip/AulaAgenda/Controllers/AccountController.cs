// Cuenta. Registra estudiantes, verifica contraseñas y administra el acceso y el perfil de la sesión.
using System.Security.Claims;
using CalendarioAcademico.Models;
using CalendarioAcademico.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CalendarioAcademico.Controllers;

public class AccountController(AcademicContext db) : Controller
{
    private readonly PasswordHasher<Student> hasher = new();

    [HttpGet]
    public IActionResult Login() => View(new AccountForm());

    [HttpGet]
    public IActionResult Register() => View(new AccountForm());

    [HttpPost]
    public async Task<IActionResult> Register(AccountForm form)
    {
        if (string.IsNullOrWhiteSpace(form.Name))
            ModelState.AddModelError("Name", "Escribe tu nombre y apellido.");

        if (form.Email.Length > 254)
            ModelState.AddModelError("Email", "El correo es demasiado largo.");

        if (!ModelState.IsValid)
            return View(form);

        var email = form.Email.Trim().ToLowerInvariant();

        if (await db.Students.AnyAsync(x => x.Email == email))
        {
            ModelState.AddModelError("", "Ese correo ya está registrado.");
            return View(form);
        }

        var s = new Student
        {
            Name = form.Name!.Trim(),
            Email = email
        };

        s.PasswordHash = hasher.HashPassword(s, form.Password);
        db.Students.Add(s);

        try
        {
            await db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            db.Entry(s).State = EntityState.Detached;

            if (!await db.Students.AnyAsync(x => x.Email == email))
                throw;

            ModelState.AddModelError("", "Ese correo ya está registrado.");
            return View(form);
        }

        await SignIn(s);
        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Login(AccountForm form)
    {
        if (!ModelState.IsValid)
            return View(form);

        var email = form.Email.Trim().ToLowerInvariant();
        var s = await db.Students
            .AsNoTracking()
            .SingleOrDefaultAsync(x => x.Email == email);

        if (s is null ||
            hasher.VerifyHashedPassword(s, s.PasswordHash, form.Password) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError("", "Correo o contraseña incorrectos.");
            return View(form);
        }

        await SignIn(s);
        return RedirectToAction("Index", "Home");
    }

    // Perfil: usa la identidad de la sesión para consultar y actualizar al estudiante.
    [Microsoft.AspNetCore.Authorization.Authorize]
    [HttpGet]
    public async Task<IActionResult> Profile()
    {
        var student = await db.Students
            .AsNoTracking()
            .SingleOrDefaultAsync(s => s.Id == User.FindFirstValue(ClaimTypes.NameIdentifier));

        if (student is null)
            return NotFound();

        ViewBag.Email = student.Email;
        return View(new ProfileForm { Name = student.Name });
    }

    [Microsoft.AspNetCore.Authorization.Authorize]
    [HttpPost]
    public async Task<IActionResult> Profile(ProfileForm form)
    {
        var studentId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var student = await db.Students.SingleOrDefaultAsync(s => s.Id == studentId);

        if (student is null)
            return NotFound();

        if (!ModelState.IsValid)
        {
            ViewBag.Email = student.Email;
            return View(form);
        }

        student.Name = form.Name.Trim();
        await db.SaveChangesAsync();

        // El menú lee el nombre desde la cookie de sesión.
        await SignIn(student);

        TempData["Notice"] = "Nombre actualizado.";
        return RedirectToAction(nameof(Profile));
    }

    private Task SignIn(Student s) =>
        HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(
                new ClaimsIdentity(
                    new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, s.Id),
                        new Claim(ClaimTypes.Name, s.Name)
                    },
                    CookieAuthenticationDefaults.AuthenticationScheme)));

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        return RedirectToAction("Login");
    }
}