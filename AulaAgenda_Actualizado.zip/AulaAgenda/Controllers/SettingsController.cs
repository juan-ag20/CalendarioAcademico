// Ajustes. Abre Soporte y guarda el orden de las actividades y la visibilidad de las ayudas.
using CalendarioAcademico.Models;
using CalendarioAcademico.Data;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CalendarioAcademico.Controllers;

[Authorize]
public class SettingsController(AcademicContext db) : Controller
{
    [HttpGet]
    public IActionResult Index() => View(AgendaPreferences.Read(HttpContext));

    [HttpGet]
    public IActionResult Support() => View();

    [HttpPost]
    public IActionResult Index(string sort, bool showHelp, string theme, bool showCompleted, bool showReminders)
    {
        if (string.IsNullOrEmpty(sort) || !AgendaPreferences.SortOptions.ContainsKey(sort))
            return BadRequest();

        new AgendaPreferences(sort, showHelp, theme == "dark" ? "dark" : "light", showCompleted, showReminders).Save(HttpContext);
        TempData["Notice"] = "Configuración guardada.";
        return RedirectToAction(nameof(Index));
    }
    // Exporta exclusivamente los datos académicos del usuario autenticado.
    [HttpPost]
    public async Task<IActionResult> Export()
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        var subjects = await db.Subjects.AsNoTracking().Where(x => x.OwnerId == id).ToListAsync();
        var activities = await db.Activities.AsNoTracking().Where(x => x.OwnerId == id).ToListAsync();
        var bytes = JsonSerializer.SerializeToUtf8Bytes(new { subjects, activities }, new JsonSerializerOptions { WriteIndented = true });
        return File(bytes, "application/json", "AulaAgenda-datos.json");
    }
}
