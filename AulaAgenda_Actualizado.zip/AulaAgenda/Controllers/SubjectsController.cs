// Materias. Consulta, crea, edita y elimina las asignaturas del estudiante autenticado.
using System.Security.Claims;
using CalendarioAcademico.Models;
using CalendarioAcademico.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CalendarioAcademico.Controllers;

[Authorize]
public class SubjectsController(AcademicContext db) : Controller
{
    private string Uid => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

    public async Task<IActionResult> Index() =>
        View(await db.Subjects
            .AsNoTracking()
            .Where(x => x.OwnerId == Uid)
            .ToListAsync());

    public async Task<IActionResult> Edit(int id = 0)
    {
        var s = id == 0
            ? new Subject()
            : await db.Subjects
                .AsNoTracking()
                .SingleOrDefaultAsync(x => x.Id == id && x.OwnerId == Uid);

        return s is null ? NotFound() : View(s);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Subject form)
    {
        if (!ModelState.IsValid)
            return View(form);

        var s = form.Id == 0
            ? new Subject { OwnerId = Uid }
            : await db.Subjects.SingleOrDefaultAsync(x => x.Id == form.Id && x.OwnerId == Uid);

        if (s is null)
            return NotFound();

        if (form.Id == 0)
            db.Subjects.Add(s);

        s.Name = form.Name;
        s.Teacher = form.Teacher;
        s.Schedule = form.Schedule;
        s.Room = form.Room;
        s.Description = form.Description;

        await db.SaveChangesAsync();
        return RedirectToAction("Index");
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var s = await db.Subjects
            .SingleOrDefaultAsync(x => x.Id == id && x.OwnerId == Uid);

        if (s is null)
            return NotFound();

        db.Subjects.Remove(s);
        await db.SaveChangesAsync();

        return RedirectToAction("Index");
    }
}