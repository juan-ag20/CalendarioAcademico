// Actividades. Filtra y ordena tareas, exámenes y apuntes. Valida su materia antes de guardar y permite cambiar el estado desde la lista.
using System.Security.Claims;
using CalendarioAcademico.Data;
using CalendarioAcademico.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CalendarioAcademico.Controllers;

[Authorize]
public class ActivitiesController(AcademicContext db) : Controller
{
    private string StudentId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    private IQueryable<Subject> Subjects => db.Subjects.Where(s => s.OwnerId == StudentId);
    private IQueryable<Activity> Activities => db.Activities.Where(a => a.OwnerId == StudentId);

    private async Task LoadSubjects()
    {
        ViewBag.Subjects = await Subjects.AsNoTracking().OrderBy(s => s.Name).ToListAsync();
    }

    public async Task<IActionResult> Index(int? subjectId, string? kind, string? sort)
    {
        await LoadSubjects();
        ViewBag.SubjectId = subjectId;
        ViewBag.Kind = kind;
        var order = sort != null && AgendaPreferences.SortOptions.ContainsKey(sort)
            ? sort : AgendaPreferences.Read(HttpContext).Sort;
        ViewBag.Sort = order;

        var query = Activities.AsNoTracking();
        if (subjectId.HasValue) query = query.Where(a => a.SubjectId == subjectId);
        if (!string.IsNullOrEmpty(kind)) query = query.Where(a => a.Kind == kind);

        var openFirst = query.OrderBy(a => a.Kind != "Apunte" && a.Status == "Completado");
        var ordered = order switch
        {
            "prioridad" => openFirst.ThenBy(a => a.Kind == "Apunte" ? 3 :
                a.Priority == "Alta" ? 0 : a.Priority == "Media" ? 1 : 2).ThenBy(a => a.Date),
            "titulo" => openFirst.ThenBy(a => a.Title).ThenBy(a => a.Date),
            _ => openFirst.ThenBy(a => a.Date).ThenBy(a => a.Title)
        };
        return View(await ordered.ThenBy(a => a.Id).ToListAsync());
    }

    public async Task<IActionResult> Edit(int id = 0, int subjectId = 0)
    {
        await LoadSubjects();
        var activity = id == 0
            ? new Activity { SubjectId = subjectId }
            : await Activities.AsNoTracking().SingleOrDefaultAsync(a => a.Id == id);
        return activity is null ? NotFound() : View(activity);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(Activity form)
    {
        if (form.Date.Year is < 1901 or > 2099)
            ModelState.AddModelError(nameof(form.Date), "Selecciona una fecha válida entre 1901 y 2099.");
        if (!await Subjects.AnyAsync(s => s.Id == form.SubjectId))
            ModelState.AddModelError(nameof(form.SubjectId), "Selecciona una de tus materias.");
        if (!ModelState.IsValid)
        {
            await LoadSubjects();
            return View(form);
        }

        var activity = form.Id == 0
            ? new Activity { OwnerId = StudentId }
            : await Activities.SingleOrDefaultAsync(a => a.Id == form.Id);
        if (activity is null) return NotFound();
        if (form.Id == 0) db.Activities.Add(activity);

        activity.SubjectId = form.SubjectId;
        activity.Title = form.Title;
        activity.Kind = form.Kind;
        activity.Description = form.Description;
        activity.Date = form.Date;
        activity.Place = form.Place;
        activity.Priority = form.Priority;
        activity.Status = form.Status;
        try
        {
            await db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            if (await Subjects.AnyAsync(s => s.Id == form.SubjectId)) throw;
            ModelState.AddModelError(nameof(form.SubjectId), "La materia fue eliminada. Selecciona otra materia.");
            await LoadSubjects();
            return View(form);
        }
        TempData["Notice"] = "Actividad guardada.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<IActionResult> UpdateStatus(int id, string status, int? subjectId, string? kind, string? sort)
    {
        if (!Activity.StatusOptions.Contains(status)) return BadRequest();
        var count = await Activities.Where(a => a.Id == id && a.Kind != "Apunte")
            .ExecuteUpdateAsync(update => update.SetProperty(a => a.Status, status));
        if (count == 0) return NotFound();

        TempData["Notice"] = "Estado actualizado.";
        return RedirectToAction(nameof(Index), new { subjectId, kind, sort });
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var activity = await Activities.SingleOrDefaultAsync(a => a.Id == id);
        if (activity is null) return NotFound();
        db.Activities.Remove(activity);
        await db.SaveChangesAsync();
        TempData["Notice"] = "Actividad eliminada.";
        return RedirectToAction(nameof(Index));
    }
}
