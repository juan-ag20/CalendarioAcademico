// Calendario. Carga las materias y actividades del estudiante y entrega a la vista el mes solicitado.
using System.Security.Claims;
using CalendarioAcademico.Models;
using CalendarioAcademico.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CalendarioAcademico.Controllers;

[Authorize]
public class HomeController(AcademicContext db) : Controller
{
    public async Task<IActionResult> Index(int? year, int? month)
    {
        var today = DateTime.Today;
        var y = year ?? today.Year;
        var m = month ?? today.Month;

        if (y < 1901 || y > 2099 || m < 1 || m > 12)
            return BadRequest();

        var uid = User.FindFirstValue(ClaimTypes.NameIdentifier)!;

        var subjects = await db.Subjects
            .AsNoTracking()
            .Where(x => x.OwnerId == uid)
            .ToListAsync();

        var activities = await db.Activities
            .AsNoTracking()
            .Where(x => x.OwnerId == uid)
            .OrderBy(x => x.Date)
            .ToListAsync();

        return View(new Dashboard(subjects, activities, new DateTime(y, m, 1)));
    }

    [AllowAnonymous]
    public IActionResult Error() =>
        Problem("Ocurrió un error. Revisa la conexión SQL Server y los registros del servidor.");
}
