// Interacción. Aplica los filtros al cambiar una selección y adapta los campos al tipo de actividad.
const filters = document.querySelector(".filters");
filters?.addEventListener("change", event => {
    if (event.target.matches("select")) filters.requestSubmit();
});

const kind = document.querySelector("#Kind");
if (kind) {
    const updateForm = () => {
        const note = kind.value === "Apunte";
        document.querySelector("#activity-details").hidden = note;
        document.querySelector("#content-label").textContent = note ? "Contenido del apunte" : "Descripción";
        document.querySelector("#date-label").textContent = note ? "Fecha y hora del apunte" : "Fecha y hora de entrega o examen";
    };
    kind.addEventListener("change", updateForm);
    updateForm();
}
