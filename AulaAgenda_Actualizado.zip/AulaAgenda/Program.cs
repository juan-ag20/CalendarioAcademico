using Microsoft.AspNetCore.DataProtection;
using CalendarioAcademico.Services;
using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
// Inicio de la aplicación. Registra MVC, SQL Server y la autenticación antes de conectar las rutas con sus controladores.
using CalendarioAcademico.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews(o => o.Filters.Add(new Microsoft.AspNetCore.Mvc.AutoValidateAntiforgeryTokenAttribute()));
var connection = builder.Configuration.GetConnectionString("AcademicConnection")
 ?? throw new InvalidOperationException("Configura ConnectionStrings:AcademicConnection.");
builder.Services.AddDbContext<AcademicContext>(o =>
 o.UseSqlServer(connection));
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o => { o.LoginPath = "/Account/Login"; o.Cookie.HttpOnly = true; o.ExpireTimeSpan = TimeSpan.FromHours(4); });
// Registra el correo y limita los intentos de recuperación por dirección IP.
builder.Services.AddScoped<RecoveryEmail>();
builder.Services.AddDataProtection();
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = 429;
    options.AddPolicy("recovery", context => RateLimitPartition.GetFixedWindowLimiter(
        context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 10, Window = TimeSpan.FromMinutes(10), QueueLimit = 0 }));
});
builder.Services.AddAuthorization();
var app = builder.Build();
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Home/Error"); app.UseHsts(); }
app.UseHttpsRedirection(); app.UseStaticFiles(); app.UseRouting(); app.UseRateLimiter(); app.UseAuthentication(); app.UseAuthorization();
app.MapControllerRoute("default", "{controller=Home}/{action=Index}/{id?}");
app.Run();
