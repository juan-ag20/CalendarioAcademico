using System.Net;
using System.Net.Mail;

namespace CalendarioAcademico.Services;

// Envía enlaces de recuperación utilizando un servidor SMTP con TLS.
public class RecoveryEmail(IConfiguration config)
{
    public async Task SendAsync(string recipient, string link)
    {
        // Las credenciales se obtienen de secretos de usuario o variables de entorno.
        var host = config["Smtp:Host"] ?? throw new InvalidOperationException("Configura SMTP.");
        var from = config["Smtp:From"] ?? throw new InvalidOperationException("Configura remitente.");
        using var smtp = new SmtpClient(host, config.GetValue("Smtp:Port", 587));
        smtp.EnableSsl = true;
        smtp.Credentials = new NetworkCredential(config["Smtp:User"], config["Smtp:Password"]);

        // El mensaje contiene un enlace temporal; nunca se envía la contraseña.
        using var mail = new MailMessage(from, recipient, "Recuperar acceso a AulaAgenda",
            $"Abre este enlace en los próximos 30 minutos: {link}\nSi no lo solicitaste, ignora el mensaje.");
        await smtp.SendMailAsync(mail);
    }
}
