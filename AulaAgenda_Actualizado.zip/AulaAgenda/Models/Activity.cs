// Actividades. Define los datos y las reglas de validación de tareas, exámenes y apuntes.
using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

public class Activity
{
    public static readonly string[] StatusOptions = { "Pendiente", "En proceso", "Completado" };
    public int Id { get; set; }
    public string OwnerId { get; set; } = "";
    public int SubjectId { get; set; }
    [Required, StringLength(150)]
    public string Title { get; set; } = "";
    [Required, RegularExpression("^(Tarea|Examen|Apunte)$")]
    public string Kind { get; set; } = "Tarea";
    [StringLength(10000)]
    public string? Description { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    [StringLength(100)]
    public string? Place { get; set; }
    [RegularExpression("^(Baja|Media|Alta)$")]
    public string Priority { get; set; } = "Media";
    [RegularExpression("^(Pendiente|En proceso|Completado)$")]
    public string Status { get; set; } = "Pendiente";
}
