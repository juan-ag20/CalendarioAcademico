// Cuenta. Define los campos y validaciones del formulario de registro e inicio de sesión.
using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

public class AccountForm
{
    [StringLength(100)]
    public string? Name { get; set; }
    [Required, EmailAddress]
    public string Email { get; set; } = "";
    [Required, StringLength(100, MinimumLength=8, ErrorMessage="La contraseña debe tener entre 8 y 100 caracteres.")]
    public string Password { get; set; } = "";
}
