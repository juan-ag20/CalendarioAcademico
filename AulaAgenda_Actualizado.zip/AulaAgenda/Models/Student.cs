// Cuenta. Representa al estudiante y conserva el hash de su contraseña para verificar el acceso.
using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

public class Student
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
}
