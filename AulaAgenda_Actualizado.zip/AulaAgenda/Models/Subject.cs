// Materias. Representa una asignatura con profesor, horario, salón y propietario.
using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

public class Subject
{
    public int Id { get; set; }
    public string OwnerId { get; set; } = "";
    [Required(ErrorMessage="Escribe el nombre."), StringLength(100)]
    public string Name { get; set; } = "";
    [StringLength(100)]
    public string? Teacher { get; set; }
    [StringLength(100)]
    public string? Schedule { get; set; }
    [StringLength(100)]
    public string? Room { get; set; }
    [StringLength(2000)]
    public string? Description { get; set; }
}
