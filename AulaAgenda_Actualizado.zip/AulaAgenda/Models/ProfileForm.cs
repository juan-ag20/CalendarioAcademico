using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

// Módulo Cuenta: limita la edición del perfil al nombre que aparece en el menú.
public class ProfileForm
{
    [Required(ErrorMessage = "Escribe tu nombre.")]
    [StringLength(100, ErrorMessage = "Usa hasta 100 caracteres.")]
    public string Name { get; set; } = "";
}
