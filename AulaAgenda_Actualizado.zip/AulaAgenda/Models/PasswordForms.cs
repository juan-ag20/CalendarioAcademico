using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

// Formulario para solicitar un enlace de recuperación.
public class ForgotPasswordForm
{
    [Required, EmailAddress, StringLength(254)]
    public string Email { get; set; } = "";
}

// El enlace contiene un token protegido, no una contraseña.
public class ResetPasswordForm
{
    [Required]
    public string Token { get; set; } = "";

    [Required, StringLength(100, MinimumLength = 8)]
    public string Password { get; set; } = "";

    [Required, Compare(nameof(Password), ErrorMessage = "Las contraseñas no coinciden.")]
    public string ConfirmPassword { get; set; } = "";
}

// Formulario de seguridad para estudiantes autenticados.
public class ChangePasswordForm
{
    [Required, StringLength(100)]
    public string CurrentPassword { get; set; } = "";

    [Required, StringLength(100, MinimumLength = 8)]
    public string Password { get; set; } = "";

    [Required, Compare(nameof(Password), ErrorMessage = "Las contraseñas no coinciden.")]
    public string ConfirmPassword { get; set; } = "";
}
