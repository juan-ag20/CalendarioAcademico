// Ajustes. Lee y escribe las preferencias de la agenda en una cookie específica del estudiante.
using System.Security.Claims;

namespace CalendarioAcademico.Models;

public record AgendaPreferences(string Sort = "fecha", bool ShowHelp = true, string Theme = "light", bool ShowCompleted = true, bool ShowReminders = true)
{
    public static readonly IReadOnlyDictionary<string, string> SortOptions =
        new Dictionary<string, string>
        {
            ["fecha"] = "Fecha más cercana",
            ["prioridad"] = "Mayor prioridad",
            ["titulo"] = "Título (A–Z)"
        };

    private static string CookieName(ClaimsPrincipal user) =>
        $"agenda.options.{user.FindFirstValue(ClaimTypes.NameIdentifier)}";

    public static AgendaPreferences Read(HttpContext context)
    {
        var values = context.Request.Cookies[CookieName(context.User)]?.Split('.');
        return values is { Length: >= 2 } && SortOptions.ContainsKey(values[0])
            ? new AgendaPreferences(values[0], values[1] != "0", values.Length > 2 && values[2] == "dark" ? "dark" : "light", values.Length < 4 || values[3] != "0", values.Length < 5 || values[4] != "0")
            : new AgendaPreferences();
    }

    public void Save(HttpContext context)
    {
        context.Response.Cookies.Append(CookieName(context.User),
            $"{Sort}.{(ShowHelp ? "1" : "0")}.{Theme}.{(ShowCompleted ? "1" : "0")}.{(ShowReminders ? "1" : "0")}",
            new CookieOptions {
                HttpOnly = true, Secure = context.Request.IsHttps,
                SameSite = SameSiteMode.Lax, MaxAge = TimeSpan.FromDays(365),
                IsEssential = true, Path = context.Request.PathBase.HasValue ? context.Request.PathBase.Value : "/"
            });
    }
}
