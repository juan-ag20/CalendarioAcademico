// Calendario. Agrupa materias, actividades y mes para construir la pantalla principal.
using System.ComponentModel.DataAnnotations;

namespace CalendarioAcademico.Models;

public record Dashboard(List<Subject> Subjects, List<Activity> Activities, DateTime Month);
